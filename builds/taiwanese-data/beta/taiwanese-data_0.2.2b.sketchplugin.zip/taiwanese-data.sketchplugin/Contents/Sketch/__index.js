var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/address.js":
/*!************************!*\
  !*** ./src/address.js ***!
  \************************/
/*! exports provided: addressjs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addressjs", function() { return addressjs; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var text = __webpack_require__(/*! sketch/dom */ "sketch/dom").Text;

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

function addressjs() {
  var dataKey = context.data.key;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (item, index) {
    var importCitiesList = __webpack_require__(/*! ./addresses/cities.json */ "./src/addresses/cities.json");

    var importPrefixesList = __webpack_require__(/*! ./addresses/prefixes.json */ "./src/addresses/prefixes.json");

    var importSuffixesList = __webpack_require__(/*! ./addresses/suffixes.json */ "./src/addresses/suffixes.json");

    var citiesList = Object.keys(importCitiesList);
    var rdPrefixesList = importPrefixesList["roads"]; // const rdSuffixesList = importSuffixesList["roads"];
    // const lnPrefixesList = '';
    //結果
    //路一定會產生，不可選。

    var addressFormat = {
      //如果未指定就是true。
      genCity: true,
      genDist: true,
      genLn: false,
      genAly: false
    };
    var addressResult = ''; //是否指定市、區

    var userInput = item.name;
    var userInputValue = userInput.split('/');
    var userCity = userInputValue[0];
    var userDist = userInputValue[1];
    checkUserInput();

    function checkUserInput() {
      if (userCity.endsWith("市")) {
        checkDist();
        addressFormat["genCity"] = false;
      } else if (userCity.endsWith("縣")) {
        checkDist();
        addressFormat["genCity"] = false;
      } else {
        addressFormat["genDist"] = true;
      }

      function checkDist() {
        if (userDist === undefined) {
          addressFormat["genDist"] = true;
        } else if (userDist === '') {
          addressFormat["genDist"] = true;
        } else {
          addressFormat["genDist"] = false;
        }
      }
    } //是否產生巷弄


    geningLn();

    function geningLn() {
      // 0.2 = 20% 機率產生
      // 產生巷
      if (Math.random() < 0.2) {
        addressFormat["genLn"] = true; // 產生弄

        if (Math.random() < 0.1) {
          addressFormat["genAly"] = true;
        }
      } else {
        addressFormat["genLn"] = false;
      }
    }

    geningResult(); //產生地址

    function geningResult() {
      var city = '';
      var dist = '';
      var rd = '';
      var ln = '';
      var aly = '';
      var no = ''; //城市

      var cityOrder = '';

      if (addressFormat["genCity"] == true) {
        //人口抽選
        cityLottery(0, 6);

        if (Math.random() < 0.3) {
          cityLottery(7, 13);
        }

        if (Math.random() < 0.2) {
          cityLottery(14, 21);
        }

        city = citiesList[cityOrder];
      } else {
        city = userCity;
      }

      function cityLottery(from, to) {
        var result = Math.random() * (to - from) + from;
        cityOrder = Math.round(result);
      } //區域


      if (addressFormat["genDist"] == true) {
        //城市是否為真
        if (importCitiesList[city] === undefined) {
          //城市為假，隨機產生區。
          var randomCity = citiesList[Math.floor(Math.random() * citiesList.length)];
          dist = importCitiesList[randomCity][Math.floor(Math.random() * importCitiesList[randomCity].length)];
        } else {
          // 城市為真，依城市產生對應的區。
          dist = importCitiesList[city][Math.floor(Math.random() * importCitiesList[city].length)];
        }
      } else {
        dist = userDist;
      } //路


      var rd = ''; // 三民北二路二段

      var pre = ''; //三民

      var dir = ''; // 北

      var num = ''; // 二

      var suff = ''; // 路

      var part = ''; // 二段
      //pre

      pre = makeRandom(rdPrefixesList); //dir

      if (Math.random() < 0.2) {
        //方位
        var dir = makeRandom(['東', '南', '西', '北']);
      } else {
        dir = '';
      } //num


      if (dir == '') {
        if (Math.random() < 0.2) {
          //數字
          num = makeRandom(['一', '二', '三', '四', '五', '六', '七', '八', '九', '十']);
        } else {
          num = '';
        }
      } else {
        num = '';
      } //suff


      suff = '路';

      if (Math.random() < 0.3) {
        suff = '街';
      }

      if (num == '') {
        if (Math.random() < 0.1) {
          suff = '大道';
        }
      } //part


      if (suff == '街') {
        part = '';
      } else {
        if (Math.random() < 0.2) {
          //後輟
          var partNum = makeRandom(['一', '二', '三', '四', '五', '六', '七', '八', '九', '十']);
          part = partNum + '段';
        }
      }

      rd = pre + dir + num + suff + part; //巷

      if (addressFormat["genLn"] == true) {
        var lnNum = Math.floor(Math.random() * (99 - 10 + 1) + 10); //一半機率產生百位數巷名

        if (Math.random() < 0.5) {
          lnNum = Math.floor(Math.random() * (999 - 100 + 1) + 100);
        }

        ln = ' ' + lnNum + ' 巷';
      } //弄


      if (addressFormat["genAly"] == true) {
        var alyNum = Math.floor(Math.random() * (99 - 10 + 1) + 10);
        aly = ' ' + alyNum + ' 弄';
      } //門牌


      var noNum = Math.floor(Math.random() * (99 - 10 + 1) + 10);

      if (Math.random() < 0.5) {
        noNum = Math.floor(Math.random() * (999 - 100 + 1) + 100);
      }

      no = ' ' + noNum + ' 號'; //結果

      addressResult = city + dist + rd + ln + aly + no;

      function makeRandom(obj) {
        return obj[Math.floor(Math.random() * obj.length)];
      } //套用


      var data = addressResult;
      DataSupplier.supplyDataAtIndex(dataKey, data, index); //復原圖層名稱

      item.name = userInput;
    }
  });
}

/***/ }),

/***/ "./src/addresses/cities.json":
/*!***********************************!*\
  !*** ./src/addresses/cities.json ***!
  \***********************************/
/*! exports provided: 台南市, 高雄市, 台中市, 台北市, 新北市, 桃園市, 基隆市, 新竹縣, 新竹市, 嘉義縣, 嘉義市, 彰化縣, 屏東縣, 花蓮縣, 南投縣, 雲林縣, 台東縣, 宜蘭縣, 澎湖縣, 金門縣, 連江縣, 苗栗縣, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"台南市\":[\"中西區\",\"東區\",\"南區\",\"北區\",\"安平區\",\"安南區\",\"永康區\",\"歸仁區\",\"新化區\",\"左鎮區\",\"玉井區\",\"楠西區\",\"南化區\",\"仁德區\",\"關廟區\",\"龍崎區\",\"官田區\",\"麻豆區\",\"佳里區\",\"西港區\",\"七股區\",\"將軍區\",\"學甲區\",\"北門區\",\"新營區\",\"後壁區\",\"白河區\",\"東山區\",\"六甲區\",\"下營區\",\"柳營區\",\"鹽水區\",\"善化區\",\"大內區\",\"山上區\",\"新市區\",\"安定區\"],\"高雄市\":[\"楠梓區\",\"左營區\",\"鼓山區\",\"三民區\",\"鹽埕區\",\"前金區\",\"新興區\",\"苓雅區\",\"前鎮區\",\"小港區\",\"旗津區\",\"鳳山區\",\"大寮區\",\"鳥松區\",\"林園區\",\"仁武區\",\"大樹區\",\"大社區\",\"岡山區\",\"路竹區\",\"橋頭區\",\"梓官區\",\"彌陀區\",\"永安區\",\"燕巢區\",\"田寮區\",\"阿蓮區\",\"茄萣區\",\"湖內區\",\"旗山區\",\"美濃區\",\"內門區\",\"杉林區\",\"甲仙區\",\"六龜區\",\"茂林區\",\"桃源區\",\"那瑪夏區\"],\"台中市\":[\"中區\",\"東區\",\"南區\",\"西區\",\"北區\",\"北屯區\",\"西屯區\",\"南屯區\",\"太平區\",\"大里區\",\"霧峰區\",\"烏日區\",\"豐原區\",\"后里區\",\"東勢區\",\"石岡區\",\"新社區\",\"和平區\",\"神岡區\",\"潭子區\",\"大雅區\",\"大肚區\",\"龍井區\",\"沙鹿區\",\"梧棲區\",\"清水區\",\"大甲區\",\"外埔區\",\"大安區\"],\"台北市\":[\"中正區\",\"大同區\",\"中山區\",\"萬華區\",\"信義區\",\"松山區\",\"大安區\",\"南港區\",\"北投區\",\"內湖區\",\"士林區\",\"文山區\"],\"新北市\":[\"板橋區\",\"新莊區\",\"泰山區\",\"林口區\",\"淡水區\",\"金山區\",\"八里區\",\"萬里區\",\"石門區\",\"三芝區\",\"瑞芳區\",\"汐止區\",\"平溪區\",\"貢寮區\",\"雙溪區\",\"深坑區\",\"石碇區\",\"新店區\",\"坪林區\",\"烏來區\",\"中和區\",\"永和區\",\"土城區\",\"三峽區\",\"樹林區\",\"鶯歌區\",\"三重區\",\"蘆洲區\",\"五股區\"],\"桃園市\":[\"桃園區\",\"中壢區\",\"平鎮區\",\"八德區\",\"楊梅區\",\"蘆竹區\",\"龜山區\",\"龍潭區\",\"大溪區\",\"大園區\",\"觀音區\",\"新屋區\",\"復興區\"],\"基隆市\":[\"仁愛區\",\"中正區\",\"信義區\",\"中山區\",\"安樂區\",\"暖暖區\",\"七堵區\"],\"新竹縣\":[\"竹北市\",\"竹東鎮\",\"新埔鎮\",\"關西鎮\",\"峨眉鄉\",\"寶山鄉\",\"北埔鄉\",\"橫山鄉\",\"芎林鄉\",\"湖口鄉\",\"新豐鄉\",\"尖石鄉\",\"五峰鄉\"],\"新竹市\":[\"東區\",\"北區\",\"香山區\"],\"嘉義縣\":[\"太保市\",\"朴子市\",\"布袋鎮\",\"大林鎮\",\"民雄鄉\",\"溪口鄉\",\"新港鄉\",\"六腳鄉\",\"東石鄉\",\"義竹鄉\",\"鹿草鄉\",\"水上鄉\",\"中埔鄉\",\"竹崎鄉\",\"梅山鄉\",\"番路鄉\",\"大埔鄉\",\"阿里山鄉\"],\"嘉義市\":[\"東區\",\"西區\"],\"彰化縣\":[\"員林鎮\",\"和美鎮\",\"鹿港鎮\",\"溪湖鎮\",\"二林鎮\",\"田中鎮\",\"北斗鎮\",\"花壇鄉\",\"芬園鄉\",\"大村鄉\",\"永靖鄉\",\"伸港鄉\",\"線西鄉\",\"福興鄉\",\"秀水鄉\",\"埔心鄉\",\"埔鹽鄉\",\"大城鄉\",\"芳苑鄉\",\"竹塘鄉\",\"社頭鄉\",\"二水鄉\",\"田尾鄉\",\"埤頭鄉\",\"溪州鄉\"],\"屏東縣\":[\"潮州鎮\",\"東港鎮\",\"恆春鎮\",\"萬丹鄉\",\"長治鄉\",\"麟洛鄉\",\"九如鄉\",\"里港鄉\",\"鹽埔鄉\",\"高樹鄉\",\"萬巒鄉\",\"內埔鄉\",\"竹田鄉\",\"新埤鄉\",\"枋寮鄉\",\"新園鄉\",\"崁頂鄉\",\"林邊鄉\",\"南州鄉\",\"佳冬鄉\",\"琉球鄉\",\"車城鄉\",\"滿州鄉\",\"枋山鄉\",\"霧台鄉\",\"瑪家鄉\",\"泰武鄉\",\"來義鄉\",\"春日鄉\",\"獅子鄉\",\"牡丹鄉\",\"三地門鄉\"],\"花蓮縣\":[\"花蓮市\",\"鳳林鎮\",\"玉里鎮\",\"新城鄉\",\"吉安鄉\",\"壽豐鄉\",\"秀林鄉\",\"光復鄉\",\"豐濱鄉\",\"瑞穗鄉\",\"萬榮鄉\",\"富里鄉\",\"卓溪鄉\"],\"南投縣\":[\"南投市\",\"埔里鎮\",\"草屯鎮\",\"竹山鎮\",\"集集鎮\",\"名間鄉\",\"鹿谷鄉\",\"中寮鄉\",\"魚池鄉\",\"國姓鄉\",\"水里鄉\",\"信義鄉\",\"仁愛鄉\"],\"雲林縣\":[\"斗六市\",\"斗南鎮\",\"虎尾鎮\",\"西螺鎮\",\"土庫鎮\",\"北港鎮\",\"莿桐鄉\",\"林內鄉\",\"古坑鄉\",\"大埤鄉\",\"崙背鄉\",\"二崙鄉\",\"麥寮鄉\",\"台西鄉\",\"東勢鄉\",\"褒忠鄉\",\"四湖鄉\",\"口湖鄉\",\"水林鄉\",\"元長鄉\"],\"台東縣\":[\"台東市\",\"成功鎮\",\"關山鎮\",\"長濱鄉\",\"海端鄉\",\"池上鄉\",\"東河鄉\",\"鹿野鄉\",\"延平鄉\",\"卑南鄉\",\"金峰鄉\",\"大武鄉\",\"達仁鄉\",\"綠島鄉\",\"蘭嶼鄉\",\"太麻里鄉\"],\"宜蘭縣\":[\"宜蘭市\",\"羅東鎮\",\"蘇澳鎮\",\"頭城鎮\",\"礁溪鄉\",\"壯圍鄉\",\"員山鄉\",\"冬山鄉\",\"五結鄉\",\"三星鄉\",\"大同鄉\",\"南澳鄉\"],\"澎湖縣\":[\"馬公市\",\"湖西鄉\",\"白沙鄉\",\"西嶼鄉\",\"望安鄉\",\"七美鄉\"],\"金門縣\":[\"金城鎮\",\"金湖鎮\",\"金沙鎮\",\"金寧鄉\",\"烈嶼鄉\",\"烏坵鄉\"],\"連江縣\":[\"南竿鄉\",\"北竿鄉\",\"莒光鄉\",\"東引鄉\"],\"苗栗縣\":[\"苗栗市\",\"通霄鎮\",\"苑裡鎮\",\"竹南鎮\",\"頭份鎮\",\"後龍鎮\",\"卓蘭鎮\",\"西湖鄉\",\"頭屋鄉\",\"公館鄉\",\"銅鑼鄉\",\"三義鄉\",\"造橋鄉\",\"三灣鄉\",\"南庄鄉\",\"大湖鄉\",\"獅潭鄉\",\"泰安鄉\"]}");

/***/ }),

/***/ "./src/addresses/prefixes.json":
/*!*************************************!*\
  !*** ./src/addresses/prefixes.json ***!
  \*************************************/
/*! exports provided: roads, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"roads\":[\"一心\",\"二聖\",\"三多\",\"四維\",\"五福\",\"六合\",\"七賢\",\"八德\",\"九如\",\"十全\",\"忠孝\",\"仁愛\",\"信義\",\"和平\",\"三民\",\"民權\",\"民族\",\"民生\",\"長榮\",\"環河\",\"中央\",\"自強\",\"自治\",\"安和\",\"沙崙\",\"淡海\",\"文化\",\"自立\",\"永康\",\"仁德\",\"保安\",\"健康\",\"博愛\",\"新生\",\"復興\",\"公園\",\"仁愛\",\"中華\",\"光明\",\"光復\",\"光華\",\"開元\",\"開山\",\"新生\",\"國華\",\"赤崁\",\"正義\",\"市政\",\"府前\",\"翠華\"]}");

/***/ }),

/***/ "./src/addresses/suffixes.json":
/*!*************************************!*\
  !*** ./src/addresses/suffixes.json ***!
  \*************************************/
/*! exports provided: roads, ln, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"roads\":[\"路\",\"街\",\"大道\"],\"ln\":[\"巷\"]}");

/***/ }),

/***/ "./src/id.js":
/*!*******************!*\
  !*** ./src/id.js ***!
  \*******************/
/*! exports provided: idjs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "idjs", function() { return idjs; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

function idjs() {
  var dataKey = context.data.key;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (item, index) {
    var distCodeList = ["D", "E", "B", "A", "F", "H", "C", "J", "O", "Q", "I", "N", "T", "U", "M", "V", "P", "G", "X", "W", "Z", "K", "L", "R", "S", "Y"];
    var distOrder = '';
    var genDist = true;
    var genGender = true;
    var IdResult = '';
    var distCode = '';
    var gender = '';
    var number = ''; //指定區域

    var userInput = item.name;
    var userInputValue = userInput.split('/');
    var userDistCode = userInputValue[0];
    var userGender = userInputValue[1];
    checkUserInput();

    function checkUserInput() {
      if (distCodeList.includes(userDistCode)) {
        genDist = false;
        distCode = userDistCode;

        if (userGender === '1') {
          genGender = false;
        } else if (userGender === '2') {
          genGender = false;
        } else if (userGender === '7') {
          genGender = false;
        } else {
          genGender = true;
        }
      } else {
        console.log('autogen');
        genDist = true;
        genGender = true;
      }
    }

    if (genDist === true) {
      var distLottery = function distLottery(from, to) {
        var result = Math.random() * (to - from) + from;
        distOrder = Math.round(result);
      };

      distLottery(0, 6);

      if (Math.random() < 0.2) {
        distLottery(7, 13);
      }

      if (Math.random() < 0.2) {
        distLottery(14, 21);
      }

      distCode = distCodeList[distOrder];
    } else {
      distCode = userDistCode;
    }

    if (genGender === true) {
      gender = '2';

      if (Math.random() < 0.5) {
        gender = '1';
      } // if (Math.random() < 0.1) {
      //     gender = '7';
      // }

    } else {
      gender = userGender;
    }

    number = Math.floor(Math.random() * (99999999 - 10000000 + 1) + 10000000);
    IdResult = distCode + gender + number;
    var data = IdResult;
    DataSupplier.supplyDataAtIndex(dataKey, data, index); //復原圖層名稱

    item.name = userInput;
  });
}

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! exports provided: onStartup, onShutdown, onNameDataNeed, onAddressDataNeed, onPhoneDataNeed, onTelephoneDataNeed, onIdDataNeed */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onStartup", function() { return onStartup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onNameDataNeed", function() { return onNameDataNeed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onAddressDataNeed", function() { return onAddressDataNeed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onPhoneDataNeed", function() { return onPhoneDataNeed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onTelephoneDataNeed", function() { return onTelephoneDataNeed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onIdDataNeed", function() { return onIdDataNeed; });
/* harmony import */ var _name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./name.js */ "./src/name.js");
/* harmony import */ var _address_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./address.js */ "./src/address.js");
/* harmony import */ var _phone_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./phone.js */ "./src/phone.js");
/* harmony import */ var _telephone_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./telephone.js */ "./src/telephone.js");
/* harmony import */ var _id_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./id.js */ "./src/id.js");
var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier; // 只要一點點  人類的溫度
// 我就能被征服
//
// 我願賭就願意  服輸
//
// 可是我心理有數
// 我不是妳的回憶錄
// 而是妳的未知數

function onStartup() {
  // To register the plugin, uncomment the relevant type:
  DataSupplier.registerDataSupplier('public.text', '1. 姓名', 'NameData');
  DataSupplier.registerDataSupplier('public.text', '2. 地址', 'AddressData');
  DataSupplier.registerDataSupplier('public.text', '3. 行動電話', 'PhoneData');
  DataSupplier.registerDataSupplier('public.text', '4. 市內電話', 'TelephoneData');
  DataSupplier.registerDataSupplier('public.text', '5. 身分證字號', 'IdData');
}
function onShutdown() {
  // Deregister the plugin
  DataSupplier.deregisterDataSuppliers();
} //姓名


function onNameDataNeed(context) {
  Object(_name_js__WEBPACK_IMPORTED_MODULE_0__["namejs"])();
} //地址


function onAddressDataNeed(context) {
  Object(_address_js__WEBPACK_IMPORTED_MODULE_1__["addressjs"])();
} //行動電話


function onPhoneDataNeed(context) {
  Object(_phone_js__WEBPACK_IMPORTED_MODULE_2__["phonejs"])();
} //室內電話


function onTelephoneDataNeed(context) {
  Object(_telephone_js__WEBPACK_IMPORTED_MODULE_3__["telephonejs"])();
} //身分證


function onIdDataNeed(context) {
  Object(_id_js__WEBPACK_IMPORTED_MODULE_4__["idjs"])();
}

/***/ }),

/***/ "./src/name.js":
/*!*********************!*\
  !*** ./src/name.js ***!
  \*********************/
/*! exports provided: namejs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "namejs", function() { return namejs; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

function namejs() {
  var dataKey = context.data.key;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (item, index) {
    var importLastNameList = __webpack_require__(/*! ./names/lastNames.json */ "./src/names/lastNames.json");

    var importFirstNameList = __webpack_require__(/*! ./names/firstNames.json */ "./src/names/firstNames.json");

    var lastNameList = importLastNameList["lastNames"];
    var firstNameList = importFirstNameList["firstNames"];

    function makeRandom(obj) {
      return obj[Math.floor(Math.random() * obj.length)];
    }

    var firstName = makeRandom(firstNameList);
    var lastName = makeRandom(lastNameList);
    var nameResult = lastName + firstName; //套用

    var data = nameResult;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

/***/ }),

/***/ "./src/names/firstNames.json":
/*!***********************************!*\
  !*** ./src/names/firstNames.json ***!
  \***********************************/
/*! exports provided: firstNames, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"firstNames\":[\"子晴\",\"詠晴\",\"子涵\",\"品妍\",\"羽彤\",\"亮妤\",\"盈蒨\",\"彥璟\",\"純甄\",\"蕙玉\",\"宸綾\",\"佩榆\",\"雅文\",\"幼薰\",\"郁筠\",\"彩禎\",\"芮禎\",\"歆茹\",\"彥霖\",\"戴樂\",\"羽綸\",\"奕淇\",\"昕霏\",\"妍霖\",\"弘珺\",\"沛妤\",\"宜蓁\",\"品蕎\",\"薇雅\",\"芊穎\",\"岱蓉\",\"台欣\",\"宜珊\",\"宜馨\",\"靖軒\",\"雯茜\",\"郁淳\",\"苡婷\",\"幼庭\",\"晴芳\",\"苡潔\",\"怡臻\",\"雨婷\",\"偉豪\",\"柏翔\",\"柏瑀\",\"琮憲\",\"澤安\",\"政峰\",\"振廷\",\"睿元\",\"承玹\",\"姵瑄\",\"育駿\",\"尚恩\",\"秉勛\",\"俊翰\",\"偉翔\",\"承翰\",\"柏睿\",\"品睿\",\"宸睿\",\"柏宇\",\"承恩\",\"承瀚\",\"宇翔\",\"冠廷\",\"冠宇\",\"柏翰\",\"彥廷\",\"柏宇\",\"宥廷\"]}");

/***/ }),

/***/ "./src/names/lastNames.json":
/*!**********************************!*\
  !*** ./src/names/lastNames.json ***!
  \**********************************/
/*! exports provided: lastNames, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"lastNames\":[\"林\",\"吳\",\"王\",\"陳\",\"楊\",\"詹\",\"張\",\"朱\",\"黃\",\"周\",\"李\",\"鄭\",\"柯\",\"廖\",\"孫\",\"薛\",\"謝\",\"蔡\",\"劉\",\"許\",\"洪\",\"郭\",\"曾\",\"賴\",\"徐\",\"沈\",\"施\",\"胡\",\"簡\",\"潘\",\"葉\",\"莊\",\"呂\",\"江\",\"何\",\"羅\",\"鐘\",\"彭\",\"游\"]}");

/***/ }),

/***/ "./src/phone.js":
/*!**********************!*\
  !*** ./src/phone.js ***!
  \**********************/
/*! exports provided: phonejs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "phonejs", function() { return phonejs; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

function phonejs() {
  var dataKey = context.data.key;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (item, index) {
    var genStart = Math.floor(Math.random() * (99 - 10 + 1) + 10);
    var genMid = Math.floor(Math.random() * (999 - 100 + 1) + 100);
    var genEnd = Math.floor(Math.random() * (999 - 100 + 1) + 100);
    var data = '09' + genStart + '-' + genMid + '-' + genEnd;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

/***/ }),

/***/ "./src/telephone.js":
/*!**************************!*\
  !*** ./src/telephone.js ***!
  \**************************/
/*! exports provided: telephonejs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "telephonejs", function() { return telephonejs; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

function telephonejs() {
  var dataKey = context.data.key;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (item, index) {
    var distNumList = ["06", "07", "04", "02", "03", "05", "08", "049", "089", "082", "0826", "0836", "037"]; // const distNum = distNumList[Math.floor(Math.random() * distNumList.length)];

    var telResult = '';
    var distNum = '';
    var genNum = true;
    var distOrder = ''; //是否指定區碼

    var userInput = item.name;
    checkUserInput();

    function checkUserInput() {
      if (userInput.endsWith("/")) {
        var userInputValue = userInput.split('/');
        var userNum = userInputValue[0];

        if (distNumList.includes(userNum) === false) {
          genNum = true;
        } else {
          genNum = false;
          distNum = userNum;
        }
      } else {
        console.log('autogen');
        genNum = true;
      }
    }

    if (genNum == true) {
      var numLottery = function numLottery(from, to) {
        var result = Math.random() * (to - from) + from;
        distOrder = Math.round(result);
      };

      numLottery(0, 5);

      if (Math.random() < 0.2) {
        numLottery(6, 8);
      }

      if (Math.random() < 0.2) {
        numLottery(9, 12);
      }

      distNum = distNumList[distOrder];
    }

    switch (distNum) {
      case '02':
        genNumber(8);
        break;

      case '03':
        genNumber(7);
        break;

      case '037':
        genNumber(6);
        break;

      case '04':
        genNumber(8);
        break;

      case '049':
        genNumber(7);
        break;

      case '05':
        genNumber(7);
        break;

      case '06':
        genNumber(7);
        break;

      case '07':
        genNumber(7);
        break;

      case '08':
        genNumber(7);
        break;

      case '082':
        genNumber(6);
        break;

      case '089':
        genNumber(6);
        break;

      case '0826':
        genNumber(5);
        break;

      case '0836':
        genNumber(5);
        break;
    }

    function genNumber(len) {
      var midNum = '';
      var lastNum = '';

      if (len === 5) {
        midNum = Math.floor(Math.random() * 99999) + 10000;
      }

      if (len === 6) {
        midNum = Math.floor(Math.random() * (999 - 100 + 1) + 100);
        lastNum = Math.floor(Math.random() * (999 - 100 + 1) + 100);
      }

      if (len === 7) {
        midNum = Math.floor(Math.random() * (999 - 100 + 1) + 100);
        lastNum = Math.floor(Math.random() * (9999 - 1000 + 1) + 1000);
      }

      if (len === 8) {
        midNum = Math.floor(Math.random() * (9999 - 1000 + 1) + 1000);
        lastNum = Math.floor(Math.random() * (9999 - 1000 + 1) + 1000);
      }

      if (len === 5) {
        telResult = distNum + '-' + midNum;
      } else {
        telResult = distNum + '-' + midNum + '-' + lastNum;
      }
    }

    var data = telResult;
    DataSupplier.supplyDataAtIndex(dataKey, data, index); //復原圖層名稱

    item.name = userInput;
  });
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onStartup'] = __skpm_run.bind(this, 'onStartup');
globalThis['onShutdown'] = __skpm_run.bind(this, 'onShutdown');
globalThis['onNameDataNeed'] = __skpm_run.bind(this, 'onNameDataNeed');
globalThis['onAddressDataNeed'] = __skpm_run.bind(this, 'onAddressDataNeed');
globalThis['onPhoneDataNeed'] = __skpm_run.bind(this, 'onPhoneDataNeed');
globalThis['onTelephoneDataNeed'] = __skpm_run.bind(this, 'onTelephoneDataNeed');
globalThis['onIdDataNeed'] = __skpm_run.bind(this, 'onIdDataNeed');
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__index.js.map