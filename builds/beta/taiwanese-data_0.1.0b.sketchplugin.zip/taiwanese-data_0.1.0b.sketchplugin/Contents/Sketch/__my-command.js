var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/my-command.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/my-command.js":
/*!***************************!*\
  !*** ./src/td.js ***!
  \***************************/
/*! exports provided: onStartup, onShutdown, onNameDataNeed, onAddressDataNeed */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onStartup", function() { return onStartup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onNameDataNeed", function() { return onNameDataNeed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onAddressDataNeed", function() { return onAddressDataNeed; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

function onStartup() {
  // To register the plugin, uncomment the relevant type:
  DataSupplier.registerDataSupplier('public.text', '台灣姓名', 'NameData');
  DataSupplier.registerDataSupplier('public.text', '台灣地址', 'AddressData');
}
function onShutdown() {
  // Deregister the plugin
  DataSupplier.deregisterDataSuppliers();
}
function onNameDataNeed(context) {
  var dataKey = context.data.key;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (item, index) {
    var importLastNameList = __webpack_require__(/*! ./names/lastNames.json */ "./src/names/lastNames.json");

    var importFirstNameList = __webpack_require__(/*! ./names/firstNames.json */ "./src/names/firstNames.json");

    var lastNameList = importLastNameList["lastNames"];
    var firstNameList = importFirstNameList["firstNames"];

    function makeRandom(obj) {
      return obj[Math.floor(Math.random() * obj.length)];
    }

    var firstName = makeRandom(firstNameList);
    var lastName = makeRandom(lastNameList);
    var nameResult = lastName + firstName;
    var data = nameResult;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}
function onAddressDataNeed(context) {
  var dataKey = context.data.key;
  var items = util.toArray(context.data.items).map(sketch.fromNative);
  items.forEach(function (item, index) {
    var lastNameList = ["林", "張", "陳", "楊", "王", "洪", "謝"];
    var firstNameList = ["品豪", "志明", "春嬌", "亮妤", "偉嘉", "美惠", "美"];

    function makeRandom(obj) {
      return obj[Math.floor(Math.random() * obj.length)];
    }

    var firstName = makeRandom(firstNameList);
    var lastName = makeRandom(lastNameList);
    var nameResult = lastName + firstName;
    var data = nameResult;
    DataSupplier.supplyDataAtIndex(dataKey, data, index);
  });
}

/***/ }),

/***/ "./src/names/firstNames.json":
/*!***********************************!*\
  !*** ./src/names/firstNames.json ***!
  \***********************************/
/*! exports provided: firstNames, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"firstNames\":[\"子晴\",\"詠晴\",\"子涵\",\"品妍\",\"羽彤\",\"亮妤\",\"盈蒨\",\"彥璟\",\"純甄\",\"蕙玉\",\"宸綾\",\"佩榆\",\"雅文\",\"幼薰\",\"郁筠\",\"彩禎\",\"芮禎\",\"歆茹\",\"彥霖\",\"戴樂\",\"羽綸\",\"奕淇\",\"昕霏\",\"妍霖\",\"弘珺\",\"沛妤\",\"宜蓁\",\"品蕎\",\"薇雅\",\"芊穎\",\"岱蓉\",\"台欣\",\"宜珊\",\"宜馨\",\"靖軒\",\"雯茜\",\"郁淳\",\"苡婷\",\"幼庭\",\"晴芳\",\"苡潔\",\"怡臻\",\"雨婷\",\"偉豪\",\"柏翔\",\"柏瑀\",\"琮憲\",\"澤安\",\"政峰\",\"振廷\",\"睿元\",\"承玹\",\"姵瑄\",\"育駿\",\"尚恩\",\"秉勛\",\"俊翰\",\"偉翔\",\"承翰\",\"柏睿\",\"品睿\",\"宸睿\",\"柏宇\",\"承恩\",\"承瀚\",\"宇翔\",\"冠廷\",\"冠宇\",\"柏翰\",\"彥廷\",\"柏宇\",\"宥廷\"]}");

/***/ }),

/***/ "./src/names/lastNames.json":
/*!**********************************!*\
  !*** ./src/names/lastNames.json ***!
  \**********************************/
/*! exports provided: lastNames, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"lastNames\":[\"林\",\"吳\",\"王\",\"陳\",\"楊\",\"詹\",\"張\",\"朱\",\"黃\",\"周\",\"李\",\"鄭\",\"柯\",\"廖\",\"孫\",\"薛\",\"謝\",\"蔡\",\"劉\",\"許\",\"洪\",\"郭\",\"曾\",\"賴\",\"徐\",\"沈\",\"施\",\"胡\",\"簡\",\"潘\",\"葉\",\"莊\",\"呂\",\"江\",\"何\",\"羅\",\"鐘\",\"彭\",\"游\"]}");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onStartup'] = __skpm_run.bind(this, 'onStartup');
globalThis['onShutdown'] = __skpm_run.bind(this, 'onShutdown');
globalThis['onNameDataNeed'] = __skpm_run.bind(this, 'onNameDataNeed');
globalThis['onAddressDataNeed'] = __skpm_run.bind(this, 'onAddressDataNeed');
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__my-command.js.map